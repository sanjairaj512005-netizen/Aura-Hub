const express = require("express");
const fs = require("fs");
const path = require("path");

const app = express();
const PORT = 3001;

app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

const DATA_FILE = path.join(__dirname, "data.json");

const defaultData = {
  users: [
    {
      id: 1,
      name: "Hospital Staff",
      email: "staff@pharmasafe.com",
      password: "pharma123",
      role: "Hospital",
      hospital: "Government Hospital - Salem"
    },
    {
      id: 2,
      name: "Admin",
      email: "admin@pharmasafe.com",
      password: "admin123",
      role: "Admin",
      hospital: "PharmaSafe Administration"
    }
  ],

  waste: [
    {
      id: 1001,
      hospital: "Government Hospital - Salem",
      wasteType: "Plastic Medical Waste",
      category: "Recyclable",
      quantity: 25,
      collector: "GreenCare Waste Services",
      status: "Collected",
      date: "2026-09-01"
    },
    {
      id: 1002,
      hospital: "Government Hospital - Salem",
      wasteType: "Used Syringes",
      category: "Hazardous",
      quantity: 12,
      collector: "SafeMed Disposal",
      status: "Safe Disposal",
      date: "2026-09-02"
    }
  ]
};

function loadData() {
  if (!fs.existsSync(DATA_FILE)) {
    fs.writeFileSync(
      DATA_FILE,
      JSON.stringify(defaultData, null, 2)
    );
  }

  return JSON.parse(
    fs.readFileSync(DATA_FILE, "utf8")
  );
}

function saveData(data) {
  fs.writeFileSync(
    DATA_FILE,
    JSON.stringify(data, null, 2)
  );
}


/* =========================
   LOGIN
========================= */

app.post("/api/login", (req, res) => {

  const { email, password } = req.body;

  const data = loadData();

  const user = data.users.find(
    u =>
      u.email.toLowerCase() ===
        String(email).toLowerCase() &&
      u.password === password
  );

  if (!user) {
    return res.status(401).json({
      success: false,
      message: "Invalid email or password"
    });
  }

  res.json({
    success: true,
    user: {
      id: user.id,
      name: user.name,
      email: user.email,
      role: user.role,
      hospital: user.hospital
    }
  });
});


/* =========================
   DASHBOARD
========================= */

app.get("/api/dashboard", (req, res) => {

  const data = loadData();

  const total = data.waste.length;

  const recyclable = data.waste.filter(
    w => w.category === "Recyclable"
  ).length;

  const hazardous = data.waste.filter(
    w => w.category === "Hazardous"
  ).length;

  const collected = data.waste.filter(
    w => w.status === "Collected"
  ).length;

  const disposed = data.waste.filter(
    w =>
      w.status === "Safe Disposal" ||
      w.status === "Recycled"
  ).length;

  res.json({
    total,
    recyclable,
    hazardous,
    collected,
    disposed,
    recent: data.waste
      .slice(-6)
      .reverse()
  });
});


/* =========================
   GET WASTE RECORDS
========================= */

app.get("/api/waste", (req, res) => {

  const data = loadData();

  res.json(
    data.waste
      .slice()
      .reverse()
  );
});


/* =========================
   ADD WASTE
========================= */

app.post("/api/waste", (req, res) => {

  const {
    hospital,
    wasteType,
    category,
    quantity,
    collector
  } = req.body;

  if (
    !hospital ||
    !wasteType ||
    !category ||
    !quantity
  ) {
    return res.status(400).json({
      success: false,
      message: "Please fill all required fields"
    });
  }

  const data = loadData();

  const newWaste = {

    id: Date.now(),

    hospital,

    wasteType,

    category,

    quantity: Number(quantity),

    collector:
      collector || "Not Assigned",

    status: "Recorded",

    date:
      new Date()
        .toISOString()
        .split("T")[0]
  };

  data.waste.push(newWaste);

  saveData(data);

  res.json({
    success: true,
    message: "Waste record added successfully",
    waste: newWaste
  });
});


/* =========================
   UPDATE TRACKING
========================= */

app.put("/api/waste/:id", (req, res) => {

  const id = Number(req.params.id);

  const data = loadData();

  const waste = data.waste.find(
    w => w.id === id
  );

  if (!waste) {

    return res.status(404).json({
      success: false,
      message: "Waste record not found"
    });

  }

  if (waste.status === "Recorded") {

    waste.status = "Collected";

  } else if (waste.status === "Collected") {

    waste.status = "In Processing";

  } else if (waste.status === "In Processing") {

    if (waste.category === "Recyclable") {
      waste.status = "Recycled";
    } else {
      waste.status = "Safe Disposal";
    }

  }

  saveData(data);

  res.json({
    success: true,
    message: "Tracking status updated",
    waste
  });
});


/* =========================
   REPORTS
========================= */

app.get("/api/reports", (req, res) => {

  const data = loadData();

  const totalQuantity =
    data.waste.reduce(
      (sum, w) =>
        sum + Number(w.quantity),
      0
    );

  const recyclableQuantity =
    data.waste
      .filter(
        w => w.category === "Recyclable"
      )
      .reduce(
        (sum, w) =>
          sum + Number(w.quantity),
        0
      );

  const hazardousQuantity =
    data.waste
      .filter(
        w => w.category === "Hazardous"
      )
      .reduce(
        (sum, w) =>
          sum + Number(w.quantity),
        0
      );

  res.json({

    totalRecords:
      data.waste.length,

    totalQuantity,

    recyclableQuantity,

    hazardousQuantity,

    hospitals: [
      ...new Set(
        data.waste.map(
          w => w.hospital
        )
      )
    ]

  });
});


/* =========================
   FRONTEND FALLBACK
   EXPRESS 5 SAFE VERSION
========================= */

app.use((req, res) => {

  res.sendFile(
    path.join(
      __dirname,
      "public",
      "index.html"
    )
  );

});


/* =========================
   START SERVER
========================= */

app.listen(PORT, () => {

  console.log("");
  console.log(
    "======================================"
  );

  console.log(
    "       PHARMASAFE SERVER"
  );

  console.log(
    "======================================"
  );

  console.log(
    `Server running at http://localhost:${PORT}`
  );

  console.log("");

});