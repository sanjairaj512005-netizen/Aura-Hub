let currentUser = null;


/* LOGIN */

const loginForm = document.getElementById("loginForm");

loginForm.addEventListener("submit", async function(e) {

  e.preventDefault();

  const email = document.getElementById("email").value.trim();
  const password = document.getElementById("password").value;

  const message = document.getElementById("loginMessage");

  message.textContent = "Checking login...";

  try {

    const response = await fetch("/api/login", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        email,
        password
      })
    });

    const data = await response.json();

    if (!data.success) {
      message.textContent = data.message;
      return;
    }

    currentUser = data.user;

    localStorage.setItem(
      "pharmasafeUser",
      JSON.stringify(currentUser)
    );

    openApplication();

  } catch (error) {

    message.textContent =
      "Server connection failed. Please start the server.";

  }

});


/* CHECK LOGIN */

window.addEventListener("DOMContentLoaded", () => {

  const savedUser = localStorage.getItem("pharmasafeUser");

  if (savedUser) {

    try {
      currentUser = JSON.parse(savedUser);
      openApplication();
    } catch {
      localStorage.removeItem("pharmasafeUser");
    }

  }

});


/* OPEN APP */

function openApplication() {

  document.getElementById("loginPage")
    .classList.add("hidden");

  document.getElementById("appPage")
    .classList.remove("hidden");

  document.getElementById("userName").textContent =
    currentUser.name;

  loadDashboard();

}


/* LOGOUT */

function logout() {

  localStorage.removeItem("pharmasafeUser");

  currentUser = null;

  location.reload();

}


/* NAVIGATION */

function showSection(sectionId, button) {

  document.querySelectorAll(".section")
    .forEach(section => {
      section.classList.add("hidden");
    });

  document.getElementById(sectionId)
    .classList.remove("hidden");

  document.querySelectorAll(".nav-btn")
    .forEach(btn => {
      btn.classList.remove("active");
    });

  if (button) {
    button.classList.add("active");
  }

  if (sectionId === "dashboard") {
    loadDashboard();
  }

  if (sectionId === "records") {
    loadRecords();
  }

  if (sectionId === "tracking") {
    loadTracking();
  }

  if (sectionId === "reports") {
    loadReports();
  }

}


/* DASHBOARD */

async function loadDashboard() {

  try {

    const response = await fetch("/api/dashboard");

    const data = await response.json();

    document.getElementById("totalRecords")
      .textContent = data.total;

    document.getElementById("recyclable")
      .textContent = data.recyclable;

    document.getElementById("hazardous")
      .textContent = data.hazardous;

    document.getElementById("collected")
      .textContent = data.collected;

    const container =
      document.getElementById("recentRecords");

    if (!data.recent.length) {

      container.innerHTML =
        "<p>No waste records available.</p>";

      return;
    }

    container.innerHTML = `
      <div class="table-wrap">
      <table>
        <thead>
          <tr>
            <th>ID</th>
            <th>Waste</th>
            <th>Category</th>
            <th>Status</th>
          </tr>
        </thead>

        <tbody>

          ${data.recent.map(w => `

            <tr>

              <td>#${w.id}</td>

              <td>
                <b>${escapeHTML(w.wasteType)}</b>
                <br>
                <small>${escapeHTML(w.date)}</small>
              </td>

              <td>
                <span class="badge ${
                  w.category === "Recyclable"
                  ? "recycle"
                  : "hazard"
                }">
                  ${w.category}
                </span>
              </td>

              <td>
                <span class="badge status">
                  ${w.status}
                </span>
              </td>

            </tr>

          `).join("")}

        </tbody>
      </table>
      </div>
    `;

  } catch (error) {

    console.log(error);

  }

}


/* ADD WASTE */

document.getElementById("wasteForm")
.addEventListener("submit", async function(e) {

  e.preventDefault();

  const wasteMessage =
    document.getElementById("wasteMessage");

  const waste = {

    hospital:
      document.getElementById("hospital").value,

    wasteType:
      document.getElementById("wasteType").value,

    category:
      document.getElementById("category").value,

    quantity:
      document.getElementById("quantity").value,

    collector:
      document.getElementById("collector").value

  };


  try {

    const response = await fetch("/api/waste", {

      method: "POST",

      headers: {
        "Content-Type": "application/json"
      },

      body: JSON.stringify(waste)

    });

    const data = await response.json();

    if (!data.success) {

      wasteMessage.textContent =
        data.message;

      return;
    }

    wasteMessage.textContent =
      "✓ Waste recorded successfully!";

    this.reset();

    document.getElementById("hospital").value =
      "Government Hospital - Salem";

    loadDashboard();

  } catch {

    wasteMessage.textContent =
      "Unable to connect to server.";

  }

});


/* RECORDS */

async function loadRecords() {

  const response =
    await fetch("/api/waste");

  const records =
    await response.json();

  const search =
    (document.getElementById("search")?.value || "")
    .toLowerCase();

  const category =
    document.getElementById("filterCategory")?.value || "";


  const filtered = records.filter(w => {

    const matchesSearch =
      w.wasteType.toLowerCase().includes(search) ||
      w.hospital.toLowerCase().includes(search) ||
      String(w.id).includes(search);

    const matchesCategory =
      !category || w.category === category;

    return matchesSearch && matchesCategory;

  });


  const container =
    document.getElementById("recordsTable");


  if (!filtered.length) {

    container.innerHTML =
      `<div class="panel">
        <p>No records found.</p>
      </div>`;

    return;
  }


  container.innerHTML = `

    <div class="table-wrap">

      <table>

        <thead>

          <tr>
            <th>Waste ID</th>
            <th>Hospital</th>
            <th>Waste Type</th>
            <th>Category</th>
            <th>Quantity</th>
            <th>Collector</th>
            <th>Status</th>
            <th>Date</th>
          </tr>

        </thead>

        <tbody>

          ${filtered.map(w => `

            <tr>

              <td>#${w.id}</td>

              <td>${escapeHTML(w.hospital)}</td>

              <td>
                <b>${escapeHTML(w.wasteType)}</b>
              </td>

              <td>
                <span class="badge ${
                  w.category === "Recyclable"
                  ? "recycle"
                  : "hazard"
                }">
                  ${w.category}
                </span>
              </td>

              <td>${w.quantity}</td>

              <td>${escapeHTML(w.collector)}</td>

              <td>
                <span class="badge status">
                  ${w.status}
                </span>
              </td>

              <td>${w.date}</td>

            </tr>

          `).join("")}

        </tbody>

      </table>

    </div>

  `;

}


/* TRACKING */

async function loadTracking() {

  const response =
    await fetch("/api/waste");

  const records =
    await response.json();

  const container =
    document.getElementById("trackingList");


  if (!records.length) {

    container.innerHTML =
      "<div class='panel'>No tracking records available.</div>";

    return;

  }


  container.innerHTML = records.map(w => {

    const steps = [
      "Recorded",
      "Collected",
      "In Processing",
      w.category === "Recyclable"
        ? "Recycled"
        : "Safe Disposal"
    ];


    let currentIndex =
      steps.indexOf(w.status);

    if (currentIndex === -1) {
      currentIndex = 0;
    }


    return `

      <div class="track-card">

        <div class="track-top">

          <div>

            <div class="track-id">
              Waste ID #${w.id}
            </div>

            <div class="track-name">
              ${escapeHTML(w.wasteType)}
            </div>

          </div>

          <span class="badge ${
            w.category === "Recyclable"
              ? "recycle"
              : "hazard"
          }">
            ${w.category}
          </span>

        </div>


        <div class="progress">

          ${steps.map((step, index) => `

            <div class="step ${
              index <= currentIndex ? "done" : ""
            }">

              <div class="step-circle">
                ${index <= currentIndex ? "✓" : index + 1}
              </div>

              <p>${step}</p>

            </div>

          `).join("")}

        </div>


        ${
          currentIndex < steps.length - 1
          ? `
            <button
              class="primary-btn"
              onclick="advanceTracking(${w.id})">
              Update Tracking →
            </button>
          `
          : `
            <p style="margin-top:20px;color:#198754;font-weight:bold">
              ✓ Final processing completed
            </p>
          `
        }

      </div>

    `;

  }).join("");

}


/* UPDATE TRACKING */

async function advanceTracking(id) {

  await fetch(`/api/waste/${id}`, {
    method: "PUT"
  });

  loadTracking();
  loadDashboard();

}


/* REPORTS */

async function loadReports() {

  const response =
    await fetch("/api/reports");

  const data =
    await response.json();


  document.getElementById("totalQuantity")
    .textContent = data.totalQuantity;

  document.getElementById("recyclableQuantity")
    .textContent = data.recyclableQuantity;

  document.getElementById("hazardousQuantity")
    .textContent = data.hazardousQuantity;

  document.getElementById("hospitalCount")
    .textContent = data.hospitals.length;

}


/* SECURITY HELPER */

function escapeHTML(value) {

  return String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");

}